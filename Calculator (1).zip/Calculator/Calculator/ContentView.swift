//
//  ContentView.swift
//  Calculator
//
//  Created by Benjamin Yeager on 3/1/23.
//

import SwiftUI

struct ContentView: View

{

    let buttons: [[CalculatorButton]] = [

        [.clear, .plusMinus, .percent, .divide],
        [.seven, .eight, .nine, .multiply],
        [.four, .five, .six, .minus],
        [.one, .two, .three, .plus],
        [.zero, .decimal, .equals]]

    

    @State var value = "0"
    @State var firstOperand: Double?
    @State var secondOperand: Double?
    @State var operation: CalculatorButton?

    

    var body: some View

    {

        ZStack(alignment: .bottom)
        {
            Color.black.ignoresSafeArea()

            VStack(spacing: 12)
            {
                HStack
                {
                    Spacer()

                    Text(value)

                        .font(.system(size: 130, weight: .light)).foregroundColor(Color.white).lineLimit(1).minimumScaleFactor(0.44)
                }

                ForEach(buttons, id: \.self)
                {
                    row in
                    HStack(spacing: 10)
                    {
                        ForEach(row, id: \.self)
                        { button in

                            CalculatorButtonView(button: button, value: $value, firstOperand: $firstOperand, secondOperand: $secondOperand, operation: $operation)

                        }

                    }

                }

                .frame(width: 100, height: 95)

            }

            .padding()

        }

    }

    

    struct CalculatorButtonView: View
    {

        let button: CalculatorButton

        @Binding var value: String
        @Binding var firstOperand: Double?
        @Binding var secondOperand: Double?
        @Binding var operation: CalculatorButton?

        
        var body: some View

        {
            Button(action:
            {
                self.handleButtonTap()
            })
            {

                Text(button.title)
                    .font(.system(size: 35, weight: .heavy))
                    .frame(width: self.buttonWidth(button) * 1.1, height: (UIScreen.main.bounds.width - 5 * 12)/4 * 1.1)
                    .foregroundColor(self.ButtonForegroundColor(_button: button))
                    .background(button.backgroundColor)
                    .cornerRadius(0)
                   

            }
            
        }

        

        private func handleButtonTap()
        {
            switch button
            {
            case .clear:
                value = "0"
                firstOperand = nil
                secondOperand = nil
                operation = nil
            case .plusMinus:
                value = String(-Double(value)!)
            case .percent:
                value = String(Double(value)! / 100)
            case .plus, .minus, .multiply, .divide:
                firstOperand = Double(value)
                operation = button
                value = "0"
            case .equals:

                if let operation = operation, let secondOperand = Double(value)
                {
                    switch operation
                    {

                    case .plus:
                        value = String(firstOperand! + secondOperand)
                    case .minus:
                        value = String(firstOperand! - secondOperand)
                    case .multiply:
                        value = String(firstOperand! * secondOperand)
                    case .divide:
                        value = String(firstOperand! / secondOperand)
                    default:
                        break

                    }

                }
                firstOperand = nil
                secondOperand = nil
                operation = nil
            default:
                if value.count < 9
                {
                    if value == "0"
                    {
                        value = button.title
                    } else
                    {
                        value += button.title
                    }
                }

            }

        }

        

        private func buttonWidth(_ button: CalculatorButton) -> CGFloat

        {

            if button == .zero
            {
                return (UIScreen.main.bounds.width - 5 * 12) / 4 * 2 + 12
            }
            return (UIScreen.main.bounds.width - 5 * 12) / 4

        }

        private func ButtonForegroundColor(_button: CalculatorButton) -> Color
        {
            if button == .clear || button == .plusMinus || button == .percent
            {
                return Color.black
            }
            return Color.white
        }
        
        
    }

    

    enum CalculatorButton

    {

        case zero, one, two, three, four, five, six, seven, eight, nine, decimal
        case equals, plus, minus, multiply, divide
        case clear, plusMinus, percent

        var title: String
        {
            switch self
            {

            case .zero:
                return "0"
            case .one:
                return "1"
            case .two:
                return "2"
            case .three:
                return "3"
            case .four:
                return "4"
            case .five:
                return "5"
            case .six:
                return "6"
            case .seven:
                return "7"
            case .eight:
                return "8"
            case .nine:
                return "9"
            case .decimal:
                return "."
            case .equals:
                return "="
            case .plus:
                return "+"
            case .minus:
                return "-"
            case .multiply:
                return "x"
            case .divide:
                return "÷"
            case .clear:
                return "AC"
            case .plusMinus:
                return "+/-"
            case .percent:
                return "%"

            }

        }

        

        var backgroundColor: Color

        {

            switch self

            {

            case .zero, .one, .two, .three, .four, .five, .six, .seven, .eight, .nine, .decimal:
                return Color(.darkGray)
            case .equals, .plus, .minus, .multiply, .divide:
                return Color(.orange)
            case .clear, .plusMinus, .percent:
                return Color(.lightGray)

            }

        }

        

        struct ContentView_Previews: PreviewProvider
        {
            static var previews: some View

            {
                ContentView()

            }

        }

    }

}

